const budgetingbox = document.getElementById('budgeting-box');
budgetingbox.addEventListener('click', () => {

  
  alert('This is working');
})